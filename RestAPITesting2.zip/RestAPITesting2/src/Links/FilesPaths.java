package Links;

public class FilesPaths {

    public static String CreatBookingJSONFile="Data\\PostData\\CreateBooking.json";
    public static String NewBookingJSONFile="Data\\PostData\\NewBooking.json";
    public static String UpdateUserJSONFile="Data\\PutData\\updateUser.json";
   
}
