package Links;

/**
 * This class Contains the used URLs in the project
 */
public class URLs {
    /**
     * baseURL is the URL of the API
     */
    public static final String BOOKING="https://restful-booker.herokuapp.com/booking";
    public static  String BOOKINGBYID="https://restful-booker.herokuapp.com/booking/$id";
    
    public static  String ReqResAPI="https://reqres.in/api/users";
    
    //https://reqres.in/api/users
    //https://reqres.in/api/users/2
    
    
    

}
