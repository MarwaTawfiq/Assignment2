package enums;

/**
 * Enum to show the status of the response of DELETE POST PUT requests.
 */
public enum ResponseStatus {
    SUCCESS,ERROR
}
